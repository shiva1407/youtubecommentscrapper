$(document).ready(function() {
    $('#testButton').on('click', function(ev) {
        console.log("Button clicked")
      play_video();
      ev.p
   
    });
});