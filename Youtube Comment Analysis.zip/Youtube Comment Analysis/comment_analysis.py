import pandas as pd
import re
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.tokenize import word_tokenize
import joblib
import os

def analyze_comments(df):
    l_com = list(df['comments'])
    comments_df = pd.DataFrame()
    comments_df['comments'] = l_com

    stops = set(stopwords.words('english'))
    stops.add("'")
    stops.add("<br>")
    stops.add("<br />")

    comments_without_sw = []
   
    for i in l_com:
        val=""
        for v in i.split():
            v=v.lower()
            if v not in stops:
                val=val+" "+v
        comments_without_sw.append(val)

    cleaned_comments=[]
    for w in comments_without_sw:
        w=re.sub('[^a-zA-Z ]',' ',w)
        cleaned_comments.append(w)

    comments_df['originalComments'] = comments_df.comments
    comments_df.comments = cleaned_comments
    comments_df['like_count'] = list(df.like_count)

    vectorizer =  joblib.load('vectorized.pkl')
    X = vectorizer.transform(cleaned_comments).toarray()

    model = joblib.load("random_forest.pkl")
    y_predict =model.predict(X)

    comments_df['sentiment'] = y_predict
    
    pos_most_liked = comments_df[comments_df.sentiment == 1.0].sort_values('like_count', ascending=False).head(5)[['originalComments', 'like_count']]
    neu_most_liked = comments_df[comments_df.sentiment == 0.0].sort_values('like_count', ascending=False).head(5)[['originalComments', 'like_count']]
    neg_most_liked = comments_df[comments_df.sentiment == -1.0].sort_values('like_count', ascending=False).head(5)[['originalComments', 'like_count']]

    return comments_df, pos_most_liked, neu_most_liked, neg_most_liked
    

if __name__ == "__main__":
    analyze_comments()